---
name: RAAS抑制剂在心力衰竭中的应用
description: 当HFrEF、HFmrEF或HFpEF患者血流动力学稳定且无禁忌证时，使用本技能根据心衰类型选择ACEI、ARB或ARNI，并逐步滴定至目标剂量。
---

# RAAS抑制剂在心力衰竭中的应用

## 适用场景
- 患者为HFrEF、HFmrEF或HFpEF
- 血流动力学稳定
- 无禁忌证（血管性水肿、妊娠、双侧肾动脉狭窄等）
- 血肌酐≤265μmol/L且血钾≤5.5mmol/L

## 执行步骤

### 1. ACEI应用
- **HFrEF**：所有患者除非禁忌均推荐使用
- **HFmrEF**：可考虑使用
- **HFpEF**：证据不足，仅在合并其他适应证时考虑
- 小剂量起始，逐渐加至靶剂量

### 2. ARB应用
- 适用于对ACEI不能耐受者替代使用
- 用法、副作用、注意事项同ACEI

### 3. ARNI应用
- **HFrEF**：推荐作为初始治疗或替换ACEI/ARB
- **HFmrEF/HFpEF**：可考虑使用
- 不可与ACEI同时使用（需停ACEI至少36小时）

## 输出结果
根据心衰类型、合并症及耐受性选择ACEI、ARB或ARNI，并逐步滴定至目标剂量。